import pandas as pd
from db.sqlite_store import (
    init_db,
    insert_mediciones,
    query_mediciones,
    get_localidades
)

# ============================================================
# INIT
# ============================================================

def init_data_layer():
    """Inicializa la capa de datos (DB, tablas, índices)."""
    init_db()

# ============================================================
# INGESTA
# ============================================================

def guardar_mediciones(df: pd.DataFrame):
    """
    Guarda nuevas mediciones en la base.
    Espera un DataFrame ya validado/procesado.
    """
    if df is None or df.empty:
        return
    insert_mediciones(df)

# ============================================================
# CONSULTAS
# ============================================================

def obtener_mediciones(
    provincia=None,
    localidad=None,
    expediente=None,
    fecha_desde=None,
    fecha_hasta=None
) -> pd.DataFrame:
    """
    Devuelve mediciones filtradas.
    Esta función es la que deben usar dashboards, mapas y tablas.
    """
    return query_mediciones(
        provincia=provincia,
        localidad=localidad,
        expediente=expediente,
        fecha_desde=fecha_desde,
        fecha_hasta=fecha_hasta
    )

def obtener_localidades() -> list:
    """Localidades únicas disponibles."""
    return get_localidades()

# ============================================================
# MÉTRICAS / RESÚMENES
# ============================================================

def resumen_general(df: pd.DataFrame) -> dict:
    """Devuelve métricas rápidas para dashboards."""
    if df is None or df.empty:
        return {
            "total_mediciones": 0,
            "max_resultado": None,
            "min_resultado": None,
            "promedio_resultado": None
        }

    return {
        "total_mediciones": len(df),
        "max_resultado": df["Resultado"].max(),
        "min_resultado": df["Resultado"].min(),
        "promedio_resultado": df["Resultado"].mean()
    }

def resumen_por_localidad(df: pd.DataFrame) -> pd.DataFrame:
    """Resumen agrupado por localidad."""
    if df is None or df.empty:
        return pd.DataFrame()

    return (
        df.groupby("Localidad", dropna=True)
        .agg(
            mediciones=("Resultado", "count"),
            max_resultado=("Resultado", "max"),
            promedio=("Resultado", "mean")
        )
        .reset_index()
        .sort_values("mediciones", ascending=False)
    )
