import pandas as pd
from data.data_service import obtener_mediciones

# ============================================================
# FILTRO PRINCIPAL
# ============================================================

def aplicar_filtros(
    provincia=None,
    localidad=None,
    expediente=None,
    fecha_desde=None,
    fecha_hasta=None,
    limite=50_000
) -> pd.DataFrame:
    """
    Aplica filtros en origen (SQLite).
    Devuelve un DF ya listo para visualización.
    """

    df = obtener_mediciones(
        provincia=provincia,
        localidad=localidad,
        expediente=expediente,
        fecha_desde=fecha_desde,
        fecha_hasta=fecha_hasta,
    )

    if df is None or df.empty:
        return df

    # Límite defensivo para UI
    if limite and len(df) > limite:
        df = df.head(limite)

    return df
