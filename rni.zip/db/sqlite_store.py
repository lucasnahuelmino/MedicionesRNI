import sqlite3
from pathlib import Path
import pandas as pd
import numpy as np
import streamlit as st

# ============================================================
# CONFIG
# ============================================================

BASE_DIR = Path(__file__).resolve().parents[1]
DB_FILE = BASE_DIR / "archivosdata" / "rni.db"
TABLE_NAME = "mediciones_rni"

# ============================================================
# DB INIT
# ============================================================

def init_db():
    """Inicializa la base y crea tabla + índices si no existen."""
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(DB_FILE)
    try:
        conn.execute(f"""
        CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
            CCTE TEXT,
            Provincia TEXT,
            Localidad TEXT,
            Resultado REAL,
            Fecha TEXT,
            Hora TEXT,
            Nombre_Archivo TEXT,
            Expediente TEXT,
            Sonda TEXT,
            Lat REAL,
            Lon REAL,
            FechaCarga TEXT
        );
        """)

        # Índices clave para rendimiento
        conn.execute("CREATE INDEX IF NOT EXISTS idx_provincia ON mediciones_rni(Provincia);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_localidad ON mediciones_rni(Localidad);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_fecha ON mediciones_rni(Fecha);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_expediente ON mediciones_rni(Expediente);")

        conn.commit()
    finally:
        conn.close()

# ============================================================
# SANITIZE
# ============================================================

def _sanitize_for_sqlite(df: pd.DataFrame) -> pd.DataFrame:
    """Convierte tipos problemáticos a formatos compatibles con SQLite."""
    if df is None or df.empty:
        return df

    out = df.copy()

    # datetime64 -> string ISO
    for col in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[col]):
            out[col] = (
                pd.to_datetime(out[col], errors="coerce")
                .dt.strftime("%Y-%m-%d %H:%M:%S")
            )

    def conv(x):
        if x is None or (isinstance(x, float) and np.isnan(x)):
            return None
        if isinstance(x, pd.Timestamp):
            return x.to_pydatetime().strftime("%Y-%m-%d %H:%M:%S")
        if hasattr(x, "isoformat"):
            try:
                return x.isoformat(sep=" ")
            except TypeError:
                return x.isoformat()
        return x

    for col in out.columns:
        if out[col].dtype == "object":
            out[col] = out[col].map(conv)

    return out

# ============================================================
# INSERT (INCREMENTAL)
# ============================================================

def insert_mediciones(df: pd.DataFrame):
    """Inserta mediciones nuevas en SQLite (append, no overwrite)."""
    if df is None or df.empty:
        return

    df2 = _sanitize_for_sqlite(df)

    conn = sqlite3.connect(DB_FILE)
    try:
        df2.to_sql(
            TABLE_NAME,
            conn,
            if_exists="append",
            index=False,
            method="multi",
            chunksize=1000
        )
    finally:
        conn.close()

# ============================================================
# QUERIES (FILTRADAS + CACHE)
# ============================================================

@st.cache_data
def query_mediciones(
    provincia=None,
    localidad=None,
    expediente=None,
    fecha_desde=None,
    fecha_hasta=None
) -> pd.DataFrame:
    """Consulta mediciones con filtros opcionales."""
    if not DB_FILE.exists():
        return pd.DataFrame()

    query = f"SELECT * FROM {TABLE_NAME} WHERE 1=1"
    params = []

    if provincia:
        query += " AND Provincia = ?"
        params.append(provincia)

    if localidad:
        query += " AND Localidad = ?"
        params.append(localidad)

    if expediente:
        query += " AND Expediente = ?"
        params.append(expediente)

    if fecha_desde and fecha_hasta:
        query += " AND Fecha BETWEEN ? AND ?"
        params.extend([fecha_desde, fecha_hasta])

    conn = sqlite3.connect(DB_FILE)
    try:
        df = pd.read_sql(query, conn, params=params)
    finally:
        conn.close()

    return df

# ============================================================
# UTILS
# ============================================================

def get_localidades() -> list:
    """Devuelve localidades únicas."""
    if not DB_FILE.exists():
        return []

    conn = sqlite3.connect(DB_FILE)
    try:
        rows = conn.execute(
            f"SELECT DISTINCT Localidad FROM {TABLE_NAME} WHERE Localidad IS NOT NULL ORDER BY Localidad"
        ).fetchall()
    finally:
        conn.close()

    return [r[0] for r in rows]
