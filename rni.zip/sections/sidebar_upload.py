from datetime import datetime
import streamlit as st
from streamlit import rerun

from admin.actions import eliminar_localidad
from db.sqlite_store import insert_mediciones
from processing.excel_processor import procesar_archivos_cacheados


def render_sidebar(sb=None):
    sb = sb or st.sidebar

    sb.header("Cargar archivos")

    def reset_form():
        for key in ["form_localidad", "form_expediente", "form_ccte", "form_provincia"]:
            st.session_state[key] = ""
        st.session_state["uploader_key"] += 1
        rerun()

    with sb.form("carga_form"):
        ccte = sb.selectbox(
            "CCTE",
            ["CABA", "Buenos Aires", "Comodoro Rivadavia", "Córdoba", "Neuquén", "Posadas", "Salta"],
            key="form_ccte"
        )

        provincia = sb.selectbox(
            "Provincia",
            [
                "Buenos Aires","CABA","Catamarca","Chaco","Chubut","Córdoba","Corrientes","Entre Ríos","Formosa","Jujuy",
                "La Pampa","La Rioja","Mendoza","Misiones","Neuquén","Río Negro","Salta","San Juan","San Luis","Santa Cruz",
                "Santa Fe","Santiago del Estero","Tierra del Fuego","Tucumán"
            ],
            key="form_provincia"
        )

        localidad = sb.text_input("Localidad", key="form_localidad")
        expediente = sb.text_input("Expediente", key="form_expediente")

        uploaded_files = sb.file_uploader(
            "Seleccionar archivos Excel",
            type=["xlsx"],
            accept_multiple_files=True,
            key=f"uploader_{st.session_state.get('uploader_key', 0)}"
        )

        submit = sb.form_submit_button("Procesar archivos")

    if submit and uploaded_files:
        with st.spinner("Procesando archivos…"):
            files_bytes = [f.getvalue() for f in uploaded_files]
            files_names = [f.name for f in uploaded_files]

            df_proc, resumen_df = procesar_archivos_cacheados(
                files_bytes,
                files_names,
                ccte,
                provincia,
                localidad,
                expediente
            )

        if not df_proc.empty:
            df_proc["FechaCarga"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            # 👉 INSERT incremental, no overwrite
            insert_mediciones(df_proc)

            sb.success(f"{len(uploaded_files)} archivos procesados correctamente.")
            sb.dataframe(resumen_df, use_container_width=True)

            st.session_state["uploader_key"] += 1
        else:
            sb.warning("No se procesaron archivos válidos.")

    sb.button("Restablecer formulario", on_click=reset_form)

    # ---------------- eliminar localidad ----------------
    if sb.checkbox("Administrar localidades"):
        localidades = eliminar_localidad.get_localidades()
        loc = sb.selectbox("Localidad a eliminar", [""] + localidades)

        if sb.button("❌ Eliminar") and loc:
            eliminar_localidad(loc)
            sb.success(f"Localidad '{loc}' eliminada.")
            rerun()
