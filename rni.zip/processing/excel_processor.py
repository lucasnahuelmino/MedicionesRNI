import os
import pandas as pd
import streamlit as st
from io import BytesIO

from utils.excel_utils import find_index_column, extract_numeric_from_text
from utils.geo_utils import parse_dms_to_decimal


@st.cache_data(show_spinner="Procesando archivos Excel…")
def procesar_archivos_cacheados(files_bytes, files_names, ccte, provincia, localidad, expediente):
    lista_procesados = []
    resumen_archivos = []

    for file_bytes, file_name in zip(files_bytes, files_names):
        try:
            df = pd.read_excel(BytesIO(file_bytes), header=8, engine="openpyxl")
        except Exception:
            continue

        df = df.dropna(axis=1, how="all")

        idx_col = find_index_column(df)
        total_mediciones = len(df)

        if idx_col:
            idx_numeric = pd.to_numeric(df[idx_col], errors="coerce")
            df = df[idx_numeric.notna()]
            if not df.empty:
                total_mediciones = int(idx_numeric.max())

        # Mapeo de columnas
        mapping_candidates = {
            "Fecha": ["fecha"],
            "Hora": ["hora", "time"],
            "Resultado": ["resultado con incertidumbre", "resultado"],
            "Sonda": ["sonda", "sonda utilizada"],
            "Lat": ["latitud", "lat"],
            "Lon": ["longitud", "lon"],
        }

        columnas_map = {}
        for key, cands in mapping_candidates.items():
            found = next(
                (c for c in df.columns if any(cand in str(c).lower() for cand in cands)),
                None
            )
            if not found and key not in ("Lat", "Lon"):
                break
            if found:
                columnas_map[key] = found
        else:
            df = df.rename(columns={v: k for k, v in columnas_map.items()})

            df["CCTE"] = ccte
            df["Provincia"] = provincia
            df["Localidad"] = localidad
            df["Expediente"] = expediente or os.path.splitext(file_name)[0]
            df["Nombre Archivo"] = file_name

            if "Resultado" in df.columns:
                df["Resultado"] = extract_numeric_from_text(df["Resultado"]).astype("float32")

            if "Lat" in df.columns:
                df["Lat"] = df["Lat"].map(parse_dms_to_decimal).astype("float32")

            if "Lon" in df.columns:
                df["Lon"] = df["Lon"].map(parse_dms_to_decimal).astype("float32")

            # Tipos optimizados
            for col in ("Provincia", "Localidad", "CCTE", "Sonda"):
                if col in df.columns:
                    df[col] = df[col].astype("category")

            lista_procesados.append(df)

            resumen_archivos.append({
                "archivo": file_name,
                "expediente": df["Expediente"].iloc[0],
                "total mediciones": total_mediciones,
                "max_resultado": df["Resultado"].max() if "Resultado" in df.columns else None
            })

    if lista_procesados:
        return pd.concat(lista_procesados, ignore_index=True), pd.DataFrame(resumen_archivos)

    return pd.DataFrame(), pd.DataFrame()
