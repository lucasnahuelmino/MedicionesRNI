from data.db import load_mediciones, get_promedio_general

df = load_mediciones()
print(len(df))

print(get_promedio_general(anio=2025))
